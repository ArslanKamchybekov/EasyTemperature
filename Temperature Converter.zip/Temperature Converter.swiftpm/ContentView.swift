import SwiftUI

struct ContentView: View {
    @State private var inputTemp = ""
    @State private var inputUnit = 0
    
    var outputTemp: Double {
        let inputTempValue = Double(inputTemp) ?? 0
        
        if inputUnit == 0 { // Celsius to Fahrenheit
            return (inputTempValue * 9/5) + 32
        } else { // Fahrenheit to Celsius
            return (inputTempValue - 32) * 5/9
        }
    }
    
    var body: some View {
        VStack {
            Image("Logo")
                .resizable()
                .frame(width: 150, height: 150)
                .padding(.bottom, 24)
            Text("\(outputTemp, specifier: "%.2f")")
                .font(.system(size: 36))
            Divider()
                .frame(width: 200)
            TextField("Enter temperature", text: $inputTemp)
                .padding()
                .frame(width: 250, height: 50)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.black, lineWidth: 2)
                )
                .keyboardType(.decimalPad)
                .padding(.vertical, 36)
            Picker("Unit", selection: $inputUnit) {
                Text("Celsius").tag(0)
                Text("Fahrenheit").tag(1)
            }
            .pickerStyle(SegmentedPickerStyle())
            .frame(width: 250)
        }
    }
}
